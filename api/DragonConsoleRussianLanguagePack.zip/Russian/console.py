import os
os.system('title DragonConsole')
import json
from colorama import init, Fore
from colorama import Back
from colorama import Style

with open('settings.json') as settingsjson:
    settingsjson = json.load(settingsjson)

import time

import tkinter
import tkinter.messagebox as mb

window = tkinter.Tk()
window.title(f"Не закрывай данный процесс. Он отвечает за сообщения")
window.geometry("1x1")
window.iconbitmap('res\\images\\msgIcon\\msgIcon.ico')
window.resizable(width = False, height = False)
window.wm_withdraw()

if settingsjson['enableIntro'] == "true":
    os.system("python res\\commands\\intro.py")
elif settingsjson['enableIntro'] == "false":
    pass
else:
    print(Fore.RED + 'Ошибка загрузки переменной "enableIntro" в "settings.json"')
    print(Fore.WHITE)

print('Напишите "help" для получения списка всех комманд')
print()
print(Fore.GREEN + 'Загрузка "settings.json"')

print('Применение пользовательского названия окна')
os.system('title ' + settingsjson['windowTitle'])
print('Загрузка пользовательских команд...')
print("Загрузка библиотек...")
print(Fore.WHITE)

try:
    from progress.bar import Bar

    libsBar = Bar('Загрузка библиотек', max=14, fill="█")

    libsBar.next()
    libsBar.next()
    import requests
    libsBar.next()
    libsBar.next()
    import webbrowser
    libsBar.next()
    import random
    libsBar.next()
    import sys
    libsBar.next()
    from win10toast import ToastNotifier
    libsBar.next()
    libsBar.next()
    libsBar.next()
    libsBar.next()
    libsBar.next()
    import pyglet
    libsBar.next()
    import platform
    libsBar.next()

    libsBar.finish()
except ImportError:
    print('\nБиблиотека не найдена')

print(Fore.GREEN)
print('Инициализация ToastNotifier')
toast = ToastNotifier()
print(Fore.WHITE)

print('Проверка версий...')
try:
    ver = requests.get(settingsjson['updateUrlVer'])
    if ver.text == settingsjson['version']:
        print(Fore.GREEN + "У вас самая последняя версия!")
        print(Fore.WHITE)
    else:
        print(Fore.RED + 'Ошибка: Твоя консоль не самой последней версий. Пожалуйста обновите консоль иначе у этой может закончится поддержка в любой момент')
        print(Fore.RED + 'Твоя версия: ' + settingsjson['version'])
        print(Fore.RED + 'Новая версия: ' + ver.text)
        print(Fore.WHITE)
        print('Скачивание обновления...')

        updateFile = open(r'DragonConsoleUpdate.zip',"wb")
        updateUrl = requests.get(settingsjson['updateUrlFile'])
        updateFile.write(updateUrl.content)
        updateFile.close()

        os.system('DragonConsoleUpdate.zip')
        os.system('taskkill /f /im python3.exe')
        os.system('taskkill /f /im python.exe')
        os.system('taskkill /f /im py.exe')
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Ошибка: Нету интернет соединения или сервера недоступны')
    print(Fore.WHITE)

while True:
    print()
    print('Логин: ' + settingsjson['username'])
    passToLogin = input('Пароль: ')
    if settingsjson['userpassword'] == passToLogin:
        break
    else:
        print()
        print(f'Неправильный пароль')
        os.system('cls')

print(Fore.GREEN + 'Проверка OS')
print(Fore.WHITE)
platformOS = platform.system()
while True:
    if settingsjson['BypassPlatformOSCheck'] == 'true':
        print(Fore.YELLOW + 'ВНИМАНИЕ: Параметр "BypassPlatformOSCheck" включен. МОЖЕТ БЫТЬ, КОНСОЛЬ СЕЙЧАС НАЧНЕТ РАБОТАТЬ НЕПРАВИЛЬНО')
        print(Fore.WHITE)
    if settingsjson['BypassPlatformOSCheck'] == 'false':
        if platformOS == 'Linux':
            print(Fore.RED + 'К сожалению, консоль не поддерживается в Linux. Пожалуйста, установите Windows, потому что DragonConsole не поддерживает Linux')
            print(Fore.RED + 'Но вы можете попробовать включить «BypassPlatformOSCheck» в файле «settings.json». Я НЕ РЕКОМЕНДУЮ раскрывать этот ПАРАМЕТР, ПОТОМУ ЧТО КОНСОЛЬ НАЧНЕТ РАБОТАТЬ НЕПРАВИЛЬНО')
            print(Fore.WHITE)
            os.system('cls')
        if platformOS == 'Windows':
            print(Fore.GREEN + 'У вас стоит Windows!')
            print(Fore.WHITE)
            break
        else:
            print(Fore.RED + 'Ошибка: Неизвестное название операционной системы')
            print(Fore.WHITE)
            os.system('cls')
    else:
        if platformOS == 'Linux':
            print(Fore.RED + 'К сожалению, консоль не поддерживается в Linux. Пожалуйста, установите Windows, потому что DragonConsole не поддерживает Linux')
            print(Fore.RED + 'Но вы можете попробовать включить «BypassPlatformOSCheck» в файле «settings.json». Я НЕ РЕКОМЕНДУЮ раскрывать этот ПАРАМЕТР, ПОТОМУ ЧТО КОНСОЛЬ НАЧНЕТ РАБОТАТЬ НЕПРАВИЛЬНО')
            print(Fore.WHITE)
            os.system('cls')
        if platformOS == 'Windows':
            print(Fore.GREEN + 'У вас стоит Windows!')
            print(Fore.WHITE)
            break
        else:
            print(Fore.RED + 'Ошибка: Неизвестное название операционной системы')
            print(Fore.WHITE)
            os.system('cls')

while True:
    command = input("> ")

    if command == 'help':
        if settingsjson['helpEnabled'] == "true":
            os.system("python res\\commands\\help.py")

        elif settingsjson['helpEnabled'] == "false":
            print(Fore.RED + 'Ошибка: Команда "help" выключена. Для использования данной команды включите её в "settings.json"')
            print(Fore.WHITE)

        else:
            print(Fore.RED + 'Ошибка загрузки переменной "helpEnabled" в "settings.json"')
            print(Fore.WHITE)


    if command == 'url get':
        urlget = input("Пожалуйста введите URL: ")
        try:
            getreq = requests.get(urlget)
            print(getreq)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Ошибка: Нету доступа к интернету или сервера недоступны')
            print(Fore.WHITE)

    if command == 'url post':
        urlpost = input("Please enter an a URL: ")
        try:
            postreq = requests.post(urlpost)
            print(postreq)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Ошибка: Нету доступа к интернету или сервера недоступны')
            print(Fore.WHITE)
    
    if command == 'yt download audio':
        os.system("python res\\commands\\ytDownloadAudio.py")

    if command == 'yt download video':
        os.system("python res\\commands\\ytDownloadVideo.py")

    if command == 'execute':
        excommand = input("Команда (Только команды из cmd.exe)> ")
        os.system(excommand)

    if command == 'open website':
        site = input("Вебсайт: ")
        webbrowser.open(f'{site}', new=2)

    if command == 'connect discordbot readmessages':
        os.system("readmessages.py")

    if command == 'cls':
        os.system('cls')

    if command == 'sleep':
        sleeptime = input("Время для сна: ")
        os.system('cls')
        print(f'Консоль на время выключена. Пожалуйста подождите {sleeptime} секунд')
        time.sleep(int(sleeptime))
        os.system('cls')

    if command == 'sleep arguments':
        print('Синтакс: sleep [-аргумент]')
        print(' -passwordToTurnOn: Для включения консоли потребуется пароль')

    if command == 'sleep -passwordToTurnOn':
        while True:
            os.system('cls')
            print(f'Консоль на время выключена. Чтобы её снова включить, введите пароль')
            password = input('Пароль: ')
            if password == settingsjson['passwordToTurnOn']:
                os.system('cls')
                break
            else:
                os.system('cls')

    if command == 'explorer':
        os.system('explorer.exe')

    if command == 'settings':
        print('Открытие "settings.json..."')
        os.system('notepad settings.json')
    
    if command == 'reportBug':
        os.system("python res\\commands\\reportBug.py")

    if command == 'server':
        os.system('python server.py')

    if command == 'checkVer':
        try:
            ver = requests.get('https://dragonfire.7m.pl/api/dragonconsole/version.txt')
            if ver.text == settingsjson['version']:
                print(Fore.GREEN + "У вас самая последняя версия!")
                print(Fore.WHITE)
            else:
                print(Fore.RED + 'Ошибка: Твоя консоль не самой последней версий. Пожалуйста обновите консоль иначе у этой может закончится поддержка в любой момент')
                print(Fore.RED + 'Твоя версия: ' + settingsjson['version'])
                print(Fore.RED + 'Новая версия: ' + ver.text)
                print(Fore.WHITE)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Ошибка: Нету доступа к интернету или сервера недоступны')
            print(Fore.WHITE)

    if command == 'changelog':
        try:
            changelog = requests.get(settingsjson["changeLogUrl"])
            print(changelog.text)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Ошибка: Нету доступа к интернету или сервера недоступны')
            print(Fore.WHITE)

    if command == 'postNotification':
        notificationName = input('Название уведомления: ')
        notificationDescription = input('Описание уведомления: ')
        notificationDuration = int(input('Время уведомления: '))
        toast.show_toast(notificationName, notificationDescription, duration=notificationDuration)

    if command == 'customCommand':
        customCommandExec = input('ПользовательскаяКоманда> ')
        testForAvailableFolder = os.access(path = 'res\\customCommands', mode = 1)
        testForAvailableCustomCommand = os.access(path = f'res\\customCommands\\{customCommandExec}.py', mode = 1)

        if testForAvailableFolder == False:
            print(Fore.RED + 'Ошибка: Папка недоступна')
            print(Fore.WHITE)
        if testForAvailableFolder == True:
            print(Fore.GREEN + 'Лог: Папка доступна')
            print(Fore.WHITE)
            if testForAvailableCustomCommand == True:
                print(Fore.GREEN + f'Лог: Команда доступна')
                print(Fore.GREEN + f'Лог: Выполнение команды { customCommandExec }')
                print(Fore.WHITE)
                os.system(f"python res\\customCommands\\{customCommandExec}.py")
            if testForAvailableCustomCommand == False:
                print(Fore.RED + 'Ошибка: Команда недоступна или не найдена')
                print(Fore.WHITE)

    if command == 'parseSystemInfo':
        os.system("python res\\commands\\parseSystemInfo.py")

    if command == 'dcProcesses':
        os.system("python res\\commands\\dcProcesses.py")

    if command == 'mlo':
        os.system("python res\\commands\\mlOnline.py")

    if command == 'switchLang':
        print('Изменение языка (Бета)')
        print('Языки: ru-RU, en-US')
        selLang = input('Выбор: ')
        if command == 'ru-RU':
            print('Ошибка: Русский Языковой Пакет для DragonConsole уже установлен')
        if command == 'en-US':
            print('Скачивание English Language Pack for DragonConsole...')
            RussianFile = open(r'DragonConsoleEnglishLanguagePack.zip',"wb")
            RussianUrl = requests.get(settingsjson['EnglishPackURL'])
            RussianFile.write(RussianUrl.content)
            RussianFile.close()

        os.system('DragonConsoleEnglishLanguagePack.zip')

    if command == 'exit':
        sys.exit(0)