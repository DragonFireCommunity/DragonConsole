import requests

print(Fore.YELLOW + 'ВНИМАНИЕ')
print(Fore.RED + "Пожалуйста, не включайте , или ' в информацию об ошибке, иначе сообщение об ошибке не будет отправлено")
buginfo = input(Fore.WHITE + 'Bug info: ')
print(Fore.GREEN + 'Отправка информаций о ошибке, пожалуйста подождите...')

try:
    requests.post(f'http://dragonfire.7m.pl/api/reportBugDC.php?reportText=' + buginfo)
    print(Fore.GREEN + 'Готово')
    print(Fore.WHITE)
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Ошибка: Нету подключения к интернету или сервера недоступны')
    print(Fore.WHITE)