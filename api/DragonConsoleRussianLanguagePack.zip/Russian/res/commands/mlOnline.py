import requests
import os


mloList = requests.get('https://raw.githubusercontent.com/DragonFire1230/DragonConsole/main/api/musicList.txt')
print(mloList.text)

musicID = input('ID Музыки: ')

print('Скачивание...')

musicFile = open(r'res//temp//musicFile.mp3',"wb")
musicUrl = requests.get('https://github.com/DragonFire1230/DragonConsole/raw/main/mlo/' + musicID + '.mp3')
musicFile.write(musicUrl.content)
musicFile.close()

print('Готово')
print('Музыка скачана в "res/temp/musicFile.mp3"')
input('Нажмите Enter чтобы завершить')