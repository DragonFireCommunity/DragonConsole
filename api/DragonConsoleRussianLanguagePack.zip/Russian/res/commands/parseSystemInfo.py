import os
import platform

print('Пожалуйста подождите')
print()
print('----------ИНФО ОС----------')
print('Название ОС: ' + os.name)
print('Вошли как: ' + os.getlogin())
print('ID Процесса: ' + str(os.getpid()))
print('Текущая работующяя директория: ' + os.getcwd())
print('Процессор: ' + platform.processor())
print('Название ОС: ' + platform.system())
print('Системный релиз: ' + platform.release())
print('Тип машины (i386, AMD64): ' + platform.machine())
print('Название сети: ' + platform.node())
print('-------ИНФО О Python-------')
print('Сборка Python: ' + str(platform.python_build()))
print('Компилятор Python: ' + platform.python_compiler())
print('Ветка Python (main, dev, tags/v3.9.8): ' + platform.python_branch())