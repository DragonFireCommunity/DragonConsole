from flask import Flask
import json
import os
import webbrowser

app = Flask(__name__)
serverip = f'127.8.6.3'

with open('settings.json') as settingsjson:
    settingsjson = json.load(settingsjson)

@app.route("/")
def index():
    return f"<a href='http://{serverip}:5000/api/settings.json'>Получить файл DragonConsole 'settings.json'</a> <br> <a href='http://{serverip}:5000/api/dragonconsole.py'>Запустить DragonConsole</a> <br> <a>Сайт создан DragonFire. Усилено с помощью Python</a>"

@app.route("/api/settings.json")
def settings():
    print()
    print(f"Password To Turn On: " + settingsjson['passwordToTurnOn'])
    print(f'Username: ' + settingsjson['username'])
    print(f'Password: ' + settingsjson['userpassword'])
    print(f'Help enabled: ' + settingsjson['helpEnabled'])
    print(f'Window Title: ' + settingsjson['windowTitle'])
    print(f'Version: ' + settingsjson['version'])
    print()
    return f'Information sended to console, please check it'

@app.route("/runningdc")
def runningdc():
    return 'DragonConsole запускается в консоли, пожалуйста проверьте это'

@app.route("/api/dragonconsole.py")
def console():
    webbrowser.open(f'http://{serverip}:5000/runningdc', new=2)
    os.system('python console.py')

if __name__ == "__main__":
    app.run(debug = 1,host = f'{serverip}', port = 5000)
