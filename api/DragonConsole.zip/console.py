import os
os.system('title DragonConsole')
import json
from colorama import init, Fore
from colorama import Back
from colorama import Style

with open('settings.json') as settingsjson:
    settingsjson = json.load(settingsjson)

import time

import tkinter
import tkinter.messagebox as mb

window = tkinter.Tk()
window.wm_withdraw()

if settingsjson['enableIntro'] == "true":
    os.system('cls')
    print("DragonFire presents...")
    time.sleep(2)
    print("Introducting...")
    time.sleep(2)
    os.system('cls')
    time.sleep(0.2)
    print(f'██████╗░██████╗░░█████╗░░██████╗░░█████╗░███╗░░██╗░█████╗░░█████╗░███╗░░██╗░██████╗░█████╗░██╗░░░░░███████╗')
    time.sleep(0.2)
    print(f'██╔══██╗██╔══██╗██╔══██╗██╔════╝░██╔══██╗████╗░██║██╔══██╗██╔══██╗████╗░██║██╔════╝██╔══██╗██║░░░░░██╔════╝')
    time.sleep(0.2)
    print(f'██║░░██║██████╔╝███████║██║░░██╗░██║░░██║██╔██╗██║██║░░╚═╝██║░░██║██╔██╗██║╚█████╗░██║░░██║██║░░░░░█████╗░░')
    time.sleep(0.2)
    print(f'██║░░██║██╔══██╗██╔══██║██║░░╚██╗██║░░██║██║╚████║██║░░██╗██║░░██║██║╚████║░╚═══██╗██║░░██║██║░░░░░██╔══╝░░')
    time.sleep(0.2)
    print(f'██████╔╝██║░░██║██║░░██║╚██████╔╝╚█████╔╝██║░╚███║╚█████╔╝╚█████╔╝██║░╚███║██████╔╝╚█████╔╝███████╗███████╗')
    time.sleep(0.2)
    print(f'╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░░╚════╝░╚═╝░░╚══╝░╚════╝░░╚════╝░╚═╝░░╚══╝╚═════╝░░╚════╝░╚══════╝╚══════╝')
    time.sleep(0.2)
    print()
    print(f'█╗░░░██╗███████╗██████╗░░██████╗██╗░█████╗░███╗░░██╗  ░░███╗░░░░░██████╗░')
    time.sleep(0.2)
    print(f'██║░░░██║██╔════╝██╔══██╗██╔════╝██║██╔══██╗████╗░██║  ░████║░░░░░╚════██╗')
    time.sleep(0.2)
    print(f'╚██╗░██╔╝█████╗░░██████╔╝╚█████╗░██║██║░░██║██╔██╗██║  ██╔██║░░░░░░█████╔╝')
    time.sleep(0.2)
    print(f'░╚████╔╝░██╔══╝░░██╔══██╗░╚═══██╗██║██║░░██║██║╚████║  ╚═╝██║░░░░░░╚═══██╗')
    time.sleep(0.2)
    print(f'░░╚██╔╝░░███████╗██║░░██║██████╔╝██║╚█████╔╝██║░╚███║  ███████╗██╗██████╔╝')
    time.sleep(0.2)
    print(f'░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═════╝░╚═╝░╚════╝░╚═╝░░╚══╝  ╚══════╝╚═╝╚═════╝░')
    time.sleep(0.2)
elif settingsjson['enableIntro'] == "false":
    pass
else:
    print(Fore.RED + 'Failed to load variable "enableIntro" in "settings.json"')
    print(Fore.WHITE)

print('Type "help" for list of all commands')
print()
print(Fore.GREEN + 'Loading "settings.json"')

with open('arts.json') as artsjson:
    artsjson = json.load(artsjson)

print('Applying custom title')
os.system('title ' + settingsjson['windowTitle'])
print("Loading libraries...")
print(Fore.WHITE)

from progress.bar import Bar

libsBar = Bar('Loading libraries', max=12, fill="█")

libsBar.next()
libsBar.next()
import requests
libsBar.next()
import youtube_dl
libsBar.next()
import webbrowser
libsBar.next()
import random
libsBar.next()
import sys
libsBar.next()
from win10toast import ToastNotifier
libsBar.next()
libsBar.next()
libsBar.next()
libsBar.next()
libsBar.next()

libsBar.finish()

print(Fore.GREEN)
print('Initializing ToastNotifier')
toast = ToastNotifier()
print(Fore.WHITE)

print('Checking version...')
try:
    ver = requests.get(settingsjson['updateUrlVer'])
    if ver.text == settingsjson['version']:
        mb.showinfo(title="Info", message="You have the latest version!")
        print(Fore.WHITE)
    else:
        mb.showerror(title="Error", message="Your console is not the latest version. Please update as this version may run out of support in any moment")
        print(Fore.RED + 'Your version: ' + settingsjson['version'])
        print(Fore.RED + 'New version: ' + ver.text)
        print(Fore.WHITE)
        print('Downloading update...')

        updateFile = open(r'DragonConsoleUpdate.zip',"wb")
        updateUrl = requests.get(settingsjson['updateUrlFile'])
        updateFile.write(updateUrl.content)
        updateFile.close()

        os.system('DragonConsoleUpdate.zip')
        os.system('taskkill /f /im python3.exe')
        os.system('taskkill /f /im python.exe')
        os.system('taskkill /f /im py.exe')
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Error: No internet access or server unavailable')
    print(Fore.WHITE)

print()
print('Username: ' + settingsjson['username'])
passToLogin = input('Password: ')
if settingsjson['userpassword'] == passToLogin:
    pass
else:
    print()
    print(f'Incorrect password')
    sys.exit()

while True:
    command = input("> ")

    if command == 'help':
        if settingsjson['helpEnabled'] == "true":
            print('url [get, post]                 | Sends a request to the site')
            print('yt download [audio, video]      | Download audio/video from YouTube (Requires FFmpeg)')
            print('execute                         | Executing a command as in the cmd')
            print('open website                    | Open website in browser')
            print('connect discordbot readmessages | Start reading messages from a users on discord servers')
            print('cls                             | Clear console')
            print('sleep [time]                    | Turn off the console')
            print('sleep arguments                 | Sleep Command Arguments')
            print('explorer                        | Run "explorer.exe"')
            print('settings                        | Edit "settings.json"')
            print('reportBug                       | Report a bug')
            print('intro                           | Showing intro')
            print('server                          | Running DragonConsole Server')
            print('checkVer                        | Check DragonConsole Version')
            print('changelog                       | Check DragonConsole Changelog')
            print('postNotification                |')
            print('exit                            | Exit from console')
            print()
        elif settingsjson['helpEnabled'] == "false":
            print(Fore.RED + 'Error: Command "help" disabled. For use it please enable it in "settings.json"')
            print(Fore.WHITE)
        else:
            print(Fore.RED + 'Failed to load variable "helpEnabled" in "settings.json"')
            print(Fore.WHITE)

    if command == 'url get':
        urlget = input("Please enter an a URL: ")
        try:
            getreq = requests.get(urlget)
            print(getreq)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Error: No internet access or server unavailable')
            print(Fore.WHITE)

    if command == 'url post':
        urlpost = input("Please enter an a URL: ")
        try:
            postreq = requests.post(urlpost)
            print(postreq)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Error: No internet access or server unavailable')
            print(Fore.WHITE)
    
    if command == 'yt download audio':
        yturl = input("YouTube Video URL: ")
        ydl_opts = {
            'format' : 'bestaudio/best',
            'postprocessors' : [{
                'key' : 'FFmpegExtractAudio',
                'preferredcodec' : 'mp3',
                'preferredquality' : '192'
                }],
            }

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            ydl.download([yturl])

    if command == 'yt download video':
        yturl = input("YouTube Video URL: ")
        ydl_opts = {
            'format' : 'bestvideo/best',
            'postprocessors' : [{
                'key' : 'FFmpegExtractAudio',
                'preferredcodec' : 'mp4',
                'preferredquality' : '192'
                }],
            }

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            ydl.download([yturl])

    if command == 'execute':
        excommand = input("Command (Only CMDs commands)> ")
        os.system(excommand)

    if command == 'open website':
        site = input("Website: ")
        webbrowser.open(f'{site}', new=2)

    if command == 'connect discordbot readmessages':
        os.system("readmessages.py")

    if command == 'cls':
        os.system('cls')

    if command == 'sleep':
        sleeptime = input("Sleep time: ")
        os.system('cls')
        print(f'The console is temporarily turned off. Please wait {sleeptime} seconds')
        time.sleep(int(sleeptime))
        os.system('cls')

    if command == 'sleep arguments':
        print('Syntax: sleep [-argument]')
        print(' -passwordToTurnOn: To turn on the console you need to enter a password')

    if command == 'sleep -passwordToTurnOn':
        while True:
            os.system('cls')
            print(f'The console was turned off. To enable it, enter the password')
            password = input('Password: ')
            if password == settingsjson['passwordToTurnOn']:
                os.system('cls')
                break
            else:
                os.system('cls')

    if command == 'explorer':
        os.system('explorer.exe')

    if command == 'settings':
        print('Opening "settings.json..."')
        os.system('notepad settings.json')
    
    if command == 'reportBug':
        print(Fore.YELLOW + 'WARNING')
        print(Fore.RED + "Please do not include , or ' in the bug information, otherwise the bug will not be sent")
        buginfo = input(Fore.WHITE + 'Bug info: ')
        print(Fore.GREEN + 'Sending bug, please wait...')
        try:
            requests.post(f'http://dragonfire.7m.pl/api/reportBugDC.php?reportText=' + buginfo)
            print(Fore.GREEN + 'Done')
            print(Fore.WHITE)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Error: No internet access or server unavailable')
            print(Fore.WHITE)

    if command == 'intro':
        os.system('cls')
        print("DragonFire presents...")
        import time
        time.sleep(2)
        print("Introducting...")
        time.sleep(2)
        os.system('cls')

        time.sleep(0.2)
        print(f'██████╗░██████╗░░█████╗░░██████╗░░█████╗░███╗░░██╗░█████╗░░█████╗░███╗░░██╗░██████╗░█████╗░██╗░░░░░███████╗')
        time.sleep(0.2)
        print(f'██╔══██╗██╔══██╗██╔══██╗██╔════╝░██╔══██╗████╗░██║██╔══██╗██╔══██╗████╗░██║██╔════╝██╔══██╗██║░░░░░██╔════╝')
        time.sleep(0.2)
        print(f'██║░░██║██████╔╝███████║██║░░██╗░██║░░██║██╔██╗██║██║░░╚═╝██║░░██║██╔██╗██║╚█████╗░██║░░██║██║░░░░░█████╗░░')
        time.sleep(0.2)
        print(f'██║░░██║██╔══██╗██╔══██║██║░░╚██╗██║░░██║██║╚████║██║░░██╗██║░░██║██║╚████║░╚═══██╗██║░░██║██║░░░░░██╔══╝░░')
        time.sleep(0.2)
        print(f'██████╔╝██║░░██║██║░░██║╚██████╔╝╚█████╔╝██║░╚███║╚█████╔╝╚█████╔╝██║░╚███║██████╔╝╚█████╔╝███████╗███████╗')
        time.sleep(0.2)
        print(f'╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░░╚════╝░╚═╝░░╚══╝░╚════╝░░╚════╝░╚═╝░░╚══╝╚═════╝░░╚════╝░╚══════╝╚══════╝')
        time.sleep(0.2)
        print()
        print(f'█╗░░░██╗███████╗██████╗░░██████╗██╗░█████╗░███╗░░██╗  ░░███╗░░░░░██████╗░')
        time.sleep(0.2)
        print(f'██║░░░██║██╔════╝██╔══██╗██╔════╝██║██╔══██╗████╗░██║  ░████║░░░░░╚════██╗')
        time.sleep(0.2)
        print(f'╚██╗░██╔╝█████╗░░██████╔╝╚█████╗░██║██║░░██║██╔██╗██║  ██╔██║░░░░░░█████╔╝')
        time.sleep(0.2)
        print(f'░╚████╔╝░██╔══╝░░██╔══██╗░╚═══██╗██║██║░░██║██║╚████║  ╚═╝██║░░░░░░╚═══██╗')
        time.sleep(0.2)
        print(f'░░╚██╔╝░░███████╗██║░░██║██████╔╝██║╚█████╔╝██║░╚███║  ███████╗██╗██████╔╝')
        time.sleep(0.2)
        print(f'░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═════╝░╚═╝░╚════╝░╚═╝░░╚══╝  ╚══════╝╚═╝╚═════╝░')
        time.sleep(0.2)

    if command == 'arts':
        try:
            artID = input('Art ID: ')
            print(artsjson[f'{artID}'])
        except KeyError:
            print('Art not found')

    if command == 'server':
        os.system('python server.py')

    if command == 'checkVer':
        try:
            ver = requests.get('https://dragonfire.7m.pl/api/dragonconsole/version.txt')
            if ver.text == settingsjson['version']:
                print(Fore.GREEN + 'You have the latest version!')
                print(Fore.WHITE)
            else:
                print(Fore.RED + 'Error: Your console is not the latest version. Please update as this version may run out of support in any moment')
                print(Fore.RED + 'Your version: ' + settingsjson['version'])
                print(Fore.RED + 'New version: ' + ver.text)
                print(Fore.WHITE)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Error: No internet access or server unavailable')
            print(Fore.WHITE)

    if command == 'changelog':
        try:
            changelog = requests.get('https://dragonfire.7m.pl/api/dragonconsole/changeloglatest.txt')
            print(changelog.text)
        except requests.exceptions.ConnectionError:
            print(Fore.RED + 'Error: No internet access or server unavailable')
            print(Fore.WHITE)

    if command == 'postNotification':
        notificationName = input('Notification name: ')
        notificationDescription = input('Notification description: ')
        notificationDuration = int(input('Notification duration: '))
        toast.show_toast(notificationName, notificationDescription, duration=notificationDuration)

    if command == 'exit':
        sys.exit(0)