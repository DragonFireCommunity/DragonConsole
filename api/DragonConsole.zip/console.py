print('Loading...')
import os
os.system('title DragonConsole')
import json
from colorama import init, Fore
from colorama import Back
from colorama import Style

from datetime import datetime

current_datetime = datetime.now()

if current_datetime.year > 2023:
    os.system('cls')
    print()
    print()
    print()
    print(Back.WHITE + Fore.BLACK + 'Error occured                                       ')
    print('                                                    ')
    print('This version of DragonConsole very old              ')
    print('Please update, because some features can be not work' + Back.BLACK + Fore.WHITE)
    print()
    print()
    print()
    input('Press enter to end')
    exit()

requestsError = False

try:
    with open('res\\commands\\settings.json') as settingsjson:
        settingsjson = json.load(settingsjson)
except FileNotFoundError:
    print(Fore.RED + 'Critical Error Occured. Error: File "settings.json" not found')
    os._exit(1)
except PermissionError:
    print(Fore.RED + 'Critical Error Occured. Error: Not permissions to view "settings.json"')
    os._exit(1)

try:
    with open('res\\commands\\language.json') as languagejson:
        languagejson = json.load(languagejson)
except FileNotFoundError:
    print(Fore.RED + 'Critical Error Occured. Error: File "language.json" not found')
    os._exit(1)
except PermissionError:
    print(Fore.RED + 'Critical Error Occured. Error: Not permissions to view "language.json"')
    os._exit(1)

import time

import tkinter
import tkinter.messagebox as mb

window = tkinter.Tk()
window.title(languagejson['thisIsResponsibleForMsgs'])
window.geometry("1x1")
window.iconbitmap('res\\images\\msgIcon\\msgIcon.ico')
window.resizable(width = False, height = False)
window.wm_withdraw()

if settingsjson['enableIntro'] == "true":
    os.system("python res\\commands\\intro.py")
    print()
else:
    print(Fore.RED + languagejson['enableIntroError'])
    print(Fore.WHITE)

print(languagejson['typeHelp'])
print()
print(Fore.GREEN + languagejson['loadingSettingsJson'])

print(languagejson['apc'])
os.system('title ' + settingsjson['windowTitle'])
print(languagejson['lcc'])
print(Fore.YELLOW + languagejson['loadingLibs'])
print(Fore.WHITE)

try:
    try:
        from progress.bar import Bar

        libsBar = Bar('Loading libraries', max=6, fill=Fore.CYAN + "█" + Fore.WHITE)
        libsBar.next()
        libsBar.next()
        libsBar.next()
        libsBar.next()
        libsBar.next()
        try:
            import requests
        except ImportError:
            requestsError = True
            print('Critical error occured! Library "requests" is not found. Update system cannot be work')
        libsBar.next()

        libsBar.finish()
    except ImportError:
        print('Critical error occured! Library "progress.bar" is not found. Progress bar system cannot be work')
    except SyntaxError:
        print('Critical error occured! Library "progress.bar" is not found. Progress bar system cannot be work')
    try:
        import requests
    except ImportError:
        requestsError = True
        print('Critical error occured! Library "requests" is not found. Update system cannot be work')
except ImportError:
    print(languagejson['libNotFound'])

print('Checking version...')
if requestsError == True:
    print('Error occured')
    print('Update service is not work because "requests" library is not found')
else:
    try:
        ver = requests.get(settingsjson['updateUrlVer'])
        if ver.text == settingsjson['version']:
            print(Fore.GREEN + languagejson['dcIsLatestVersion'] + Fore.WHITE)
        else:
            print(Fore.RED + languagejson['dcNotLatestVersion'])
            print(Fore.RED + 'Your version: ' + settingsjson['version'])
            print(Fore.RED + 'New version: ' + ver.text)
            print(Fore.WHITE)
            os.system('cls')
            os.system('python res\\images\\updateScreen.py')

            updateFile = open(r'DragonConsoleUpdate.zip',"wb")
            updateUrl = requests.get(settingsjson['updateUrlFile'])
            updateFile.write(updateUrl.content)
            updateFile.close()

            os.system('DragonConsoleUpdate.zip')
            os.system("python res\\command\\killPython.py")
    except requests.exceptions.ConnectionError:
        os.system("python res\\msgBoxes\\NoInternetAccess.py")
    except requests.exceptions.RequestException:
        os.system("python res\\msgBoxes\\RequestException.py")

while True:
    print()
    print('Username> ' + settingsjson['username'])
    passToLogin = input('Password> ')
    if settingsjson['userpassword'] == passToLogin:
        break
    else:
        print()
        print(languagejson['incorrectPassword'])
        os.system('cls')

print(languagejson['extensionLoaderIntro'])
for extension in os.listdir("res\\extensions"):
    if extension.endswith((".notloaddc")):
        print('Skipped: ' + extension)
    else:
        os.system("python res\\extensions\\" + extension)
        print('Loaded extension: ' + extension)

try:
    while True:
        command = input(settingsjson['username'] + "> ")

        if command == 'help':
            if settingsjson['helpEnabled'] == "true":
                os.system("python res\\commands\\help.py")

            elif settingsjson['helpEnabled'] == "false":
                os.system("python res\\msgBoxes\\helpDisabled.py")

            else:
                os.system("python res\\msgBoxes\\helpEnabledLoadVariableError.py")


        if command == 'url get':
            os.system("python res\\commands\\urlGet.py")

        if command == 'url post':
            os.system("python res\\commands\\urlPost.py")
        
        if command == 'yt download audio':
            os.system("python res\\commands\\ytDownloadAudio.py")

        if command == 'yt download video':
            os.system("python res\\commands\\ytDownloadVideo.py")

        if command == 'execute':
            os.system("python res\\commands\\execute.py")

        if command == 'open website':
            os.system("python res\\commands\\openWebsite.py")

        if command == 'connect discordbot readmessages':
            os.system("python res\\commands\\readmessages.py")

        if command == 'cls':
            os.system('cls')

        if command == 'sleep':
            sleeptime = input("Sleep time: ")
            os.system('cls')
            print(languagejson['sleepLine1'] + f'{sleeptime} seconds')
            time.sleep(int(sleeptime))
            os.system('cls')

        if command == 'sleep arguments':
            os.system("python res\\msgBoxes\\sleepArguments.py")

        if command == 'sleep -passwordToTurnOn':
            while True:
                os.system('cls')
                print(languagejson['dcTurnedOffByPassword'])
                password = input('Password> ')
                if password == settingsjson['passwordToTurnOn']:
                    os.system('cls')
                    break
                else:
                    os.system('cls')

        if command == 'explorer':
            os.system('explorer.exe')

        if command == 'settings':
            print('Opening "settings.json..."')
            os.system('notepad res\\commands\\settings.json')
        
        if command == 'reportBug':
            os.system("python res\\commands\\reportBug.py")

        if command == 'server':
            os.system('python res\\commands\\server.py')

        if command == 'changelog':
            os.system("python res\\commands\\changeLog.py")

        if command == 'postNotification':
            os.system("python res\\commands\\postNotification.py")

        if command == 'customCommand':
            customCommandExec = input('CustomCommand> ')
            testForAvailableFolder = os.access(path = 'res\\customCommands', mode = 1)
            testForAvailableCustomCommand = os.access(path = f'res\\customCommands\\{customCommandExec}.py', mode = 1)

            if testForAvailableFolder == False:
                print(Fore.RED + 'Error: Folder unavailable')
                print(Fore.WHITE)
            if testForAvailableFolder == True:
                print(Fore.GREEN + 'Log: Folder available')
                print(Fore.WHITE)
                if testForAvailableCustomCommand == True:
                    print(Fore.GREEN + f'Log: Command available')
                    print(Fore.GREEN + f'Log: Running command { customCommandExec }')
                    print(Fore.WHITE)
                    os.system(f"python res\\customCommands\\{customCommandExec}.py")
                if testForAvailableCustomCommand == False:
                    print(Fore.RED + 'Error: Command unavailable or not found')
                    print(Fore.WHITE)

        if command == 'parseSystemInfo':
            os.system("python res\\commands\\parseSystemInfo.py")

        if command == 'mlo':
            os.system("python res\\commands\\mlOnline.py")

        if command == 'parsePage':
            os.system("python res\\commands\\parsePage.py")

        if command == 'intro':
            os.system("python res\\commands\\intro.py")

        if command == 'switchLang':
            try:
                print('Language switcher (Beta)')
                print('Languages: ru-RU, en-US')
                selLang = input('Select: ')
                if selLang == 'ru-RU':
                    print(languagejson['drlpfdc'])
                    RussianFile = open(r'DragonConsoleRussianLanguagePack.zip',"wb")
                    RussianUrl = requests.get(settingsjson['RussianPackURL'])
                    RussianFile.write(RussianUrl.content)
                    RussianFile.close()
                    os.system('DragonConsoleRussianLanguagePack.zip')
                if selLang == 'en-US':
                    print(Fore.RED + languagejson['dcEnLangPackIsInstalled'] + Fore.WHITE)
            except requests.exceptions.ConnectionError:
                os.system("python res\\msgBoxes\\NoInternetAccess.py")
            except requests.exceptions.RequestException:
                os.system("python res\\msgBoxes\\RequestException.py")

        if command == 'convertToAscii':
            pathToFileForAscii = input('Path to file> ')
            os.system("python res\\commands\\convertToAscii.py " + pathToFileForAscii)

        if command == 'reload':
            os.system('cls')
            print('Reloading...')
            time.sleep(3)
            os.system("python console.py")

        if command == 'exit':
            exit()

except KeyboardInterrupt:
    print(Fore.RED + languagejson['KeyboardInterruptError'])
    input('Press Enter to continue' + Fore.WHITE)
except MemoryError:
    print(Fore.RED + languagejson['OutOfMemoryError'])
    input('Press Enter to continue' + Fore.WHITE)
except TimeoutError:
    print(Fore.RED + languagejson['TimeoutError'])
    input('Press Enter to continue' + Fore.WHITE)