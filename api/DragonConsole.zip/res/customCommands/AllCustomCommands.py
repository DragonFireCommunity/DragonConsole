import os

AllCustomCommands = os.listdir(path = '.\\res\\customCommands')
print(AllCustomCommands)