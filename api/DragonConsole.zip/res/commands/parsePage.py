import requests

pageToParseInput = input('Page To Parse URL: ')
print('Parsing...')
pageToParse = requests.get(pageToParseInput)
print('Writing in parsed.html')
parsedPage = open('parsed.html', "a+")
parsedPage.write(pageToParse.text)
parsedPage.close()

print('Page parsed!')
print(f'Response code: {pageToParse}')