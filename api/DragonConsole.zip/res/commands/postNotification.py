from win10toast import ToastNotifier

toast = ToastNotifier()

notificationName = input('Notification name: ')
notificationDescription = input('Notification description: ')
notificationDuration = int(input('Notification duration: '))
toast.show_toast(notificationName, notificationDescription, duration=notificationDuration)