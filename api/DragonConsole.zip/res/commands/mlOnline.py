import requests
import os


mloList = requests.get('https://raw.githubusercontent.com/DragonFire1230/DragonConsole/main/api/musicList.txt')
print(mloList.text)

musicID = input('Music ID: ')

print('Downloading...')

musicFile = open(r'res//temp//musicFile.mp3',"wb")
musicUrl = requests.get('https://github.com/DragonFire1230/DragonConsole/raw/main/mlo/' + musicID + '.mp3')
musicFile.write(musicUrl.content)
musicFile.close()

print('Done')
print('Music downloaded in "res/temp/musicFile.mp3"')
input('Press Enter to continue')