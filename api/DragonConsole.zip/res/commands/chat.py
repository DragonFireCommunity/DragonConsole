import requests
import time

action = input('Action (connect, make): ')

if action == 'connect':
    chatID = input('Chat ID: ')

    try:
        print('Please wait...')
        print('Connecting...')

        print('Welcome to DragonConsole chats!')
        print('You are connect to chat: ' + chatID)
        print('Warning: This function is currently beta and works be unstable. Reporting bug by using command "reportBug"')
        print('Good luck in beta testing!')
        print('P.S: Update chat time is 5 second')
        print()
        while True:
            lastMsg = requests.get(f'https://dragonfire.7m.pl/api/dragonconsole/chats/' + chatID)
            print(lastMsg.text)
            time.sleep(5)
    except requests.exceptions.ConnectionError:
        os.system("python res\\msgBoxes\\NoInternetAccess.py")

if action == 'make':
    firstMsg = input('First message (ONLY ENGLISH): ')
    print('Making chat, please wait...')
    makeChatUrl = requests.post(f'https://dragonfire.7m.pl/api/dragonconsole/chats/makeChat.php?firstMsg=' + firstMsg)
    chatID = input('Chat ID: ')
    while True:
        message = input('Message: ')
        makeChatUrl = requests.post(f'https://dragonfire.7m.pl/api/dragonconsole/chats/sendToChat.php?id=' + chatID + '&message=' + message)