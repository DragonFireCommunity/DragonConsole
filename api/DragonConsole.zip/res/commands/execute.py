import os

excommand = input("Command (Only CMDs commands)> ")
os.system(excommand)