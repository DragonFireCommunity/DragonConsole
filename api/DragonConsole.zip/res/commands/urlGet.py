import requests

urlget = input("Please enter an a URL: ")

try:
    getreq = requests.get(urlget)
    print(getreq)
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Error: No internet access or server unavailable')
    print(Fore.WHITE)