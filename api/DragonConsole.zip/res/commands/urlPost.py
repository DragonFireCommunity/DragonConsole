import requests

urlpost = input("Please enter an a URL: ")

try:
    postreq = requests.post(urlpost)
    print(postreq)
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Error: No internet access or server unavailable')
    print(Fore.WHITE)