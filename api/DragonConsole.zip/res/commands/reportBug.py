import requests

print(Fore.YELLOW + 'WARNING')
print(Fore.RED + "Please do not include , or ' in the bug information, otherwise the bug will not be sent")
buginfo = input(Fore.WHITE + 'Bug info: ')
print(Fore.GREEN + 'Sending bug, please wait...')

try:
    requests.post(f'http://dragonfire.7m.pl/api/reportBugDC.php?reportText=' + buginfo)
    print(Fore.GREEN + 'Done')
    print(Fore.WHITE)
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Error: No internet access or server unavailable')
    print(Fore.WHITE)