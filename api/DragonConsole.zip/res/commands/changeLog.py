import requests
from colorama import init, Fore
from colorama import Back
from colorama import Style
import json

with open('res\\commands\\settings.json') as settingsjson:
    settingsjson = json.load(settingsjson)

try:
    changelog = requests.get(settingsjson["changeLogUrl"])
    print(changelog.text)
except requests.exceptions.ConnectionError:
    print(Fore.RED + 'Error: No internet access or server unavailable')
    print(Fore.WHITE)