tkn = input(f'TOKEN: ')
print("Connecting...")

import discord
from discord import *
from discord.ext import commands
import requests

bot = commands.Bot(command_prefix="", intents = discord.Intents.all())

@bot.event
async def on_ready():
    await bot.change_presence( status = discord.Status.idle, activity = discord.Game('Bot started'))
    print(f'Bot: {bot.user.name} connected!')

@bot.event
async def on_message(message):
    print(f'{ message.author }: { message.content }')
    
bot.run(f'{tkn}')
