import webbrowser

site = input("Website: ")
webbrowser.open(f'{site}', new=2)