import os

os.system('taskkill /f /im python3.exe')
os.system('taskkill /f /im python.exe')
os.system('taskkill /f /im py.exe')