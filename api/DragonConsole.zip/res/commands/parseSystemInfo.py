import os
import platform

print('Please wait')
print()
print('----------OS NAME----------')
print('OS Name: ' + os.name)
print('Logged as: ' + os.getlogin())
print('Process ID: ' + str(os.getpid()))
print('Current working directory: ' + os.getcwd())
print('Processor: ' + platform.processor())
print('OS Name: ' + platform.system())
print('System release: ' + platform.release())
print('Machine type (i386, AMD64): ' + platform.machine())
print('Network name: ' + platform.node())
print('--------PYTHON INFO--------')
print('Python build: ' + str(platform.python_build()))
print('Python compiler: ' + platform.python_compiler())
print('Python branch: ' + platform.python_branch())