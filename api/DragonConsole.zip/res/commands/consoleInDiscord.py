import discord
from discord.ext import commands
import sys
import time

bot_prefix = 'dc/'
bot_token = 'OTE4NDQ0NDE4Njc4MjYzODA4.YbHWBQ.vfS5cRrlBNqMh1OAfVg3yOeaZl0'

if len(bot_token) < 40:
    print('Get you token!')
    print('Error occured. Token not found. You can found you token at https://discord.com/developers/applications')
    print('After go to file "consoleInDiscord.py" and edit variable bot_token')
    input('Press Enter to continue')
    sys.exit()
else:
    print('Settings:')
    print(f' - Prefix: {bot_prefix}')
    print()
    print('Starting...')
    pass

bot = commands.Bot(command_prefix = f'{ bot_prefix }', intents=discord.Intents.all())

# Events

@bot.event
async def on_ready():
	print('Console started! Check discord!')

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send('Error - This command is not found')
        pass
    else:
        print(error)
        await ctx.send(f'Error - An error occurred while executing the code. Error information: ```{ error }```')
        pass

# Commands

@bot.command()
async def sleep(ctx, sleepTime):
    await ctx.send(f'The console is temporarily turned off. Please wait {sleepTime} seconds')
    time.sleep(int(sleepTime))

bot.run(bot_token)