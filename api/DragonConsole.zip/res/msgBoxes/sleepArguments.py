print('Syntax: sleep [-argument]')
print(' -passwordToTurnOn: To turn on the console you need to enter a password')