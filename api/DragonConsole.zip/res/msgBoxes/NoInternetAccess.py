from colorama import init, Fore
from colorama import Back
from colorama import Style

print(Fore.RED + 'Error: No internet access or server unavailable')
print(Fore.WHITE)