from colorama import init, Fore
from colorama import Back
from colorama import Style

print(Fore.RED + 'Error: Command "help" disabled. For use it please enable it in "settings.json"')
print(Fore.WHITE)