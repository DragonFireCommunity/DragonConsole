from colorama import init, Fore
from colorama import Back
from colorama import Style

print(Fore.RED + 'Failed to load variable "helpEnabled" in "settings.json"')
print(Fore.WHITE)