from colorama import init, Fore
from colorama import Back
from colorama import Style

print(Fore.RED + 'Error: RequestException')
print(Fore.WHITE)