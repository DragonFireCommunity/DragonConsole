from colorama import init, Fore
from colorama import Back
from colorama import Style

print(Fore.GREEN + 'You have the latest version!')
print(Fore.WHITE)